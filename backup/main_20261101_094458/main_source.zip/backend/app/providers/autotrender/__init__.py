"""AutoTrender provider integration."""
