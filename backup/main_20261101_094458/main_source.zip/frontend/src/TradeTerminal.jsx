import React, { useCallback, useEffect, useState } from 'react';

const API = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const WS_API = API ? API.replace(/^https:/, 'wss:').replace(/^http:/, 'ws:') : `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}`;
async function request(path, options = {}) {
  const response = await fetch(`${API}/api/v1${path}`, {
    ...options, headers: { Accept: 'application/json', ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `Request failed (${response.status})`);
  return data;
}
const fmt = (value) => value === null || value === undefined || value === '' ? '—' :
  typeof value === 'number' ? value.toLocaleString('en-IN', { maximumFractionDigits: 2 }) : String(value);
const formatPnl = (value) => {
  if (value === null || value === undefined || value === '' || !Number.isFinite(Number(value))) return '—';
  return Number(value).toLocaleString('en-IN', {
    style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2,
    signDisplay: 'exceptZero',
  });
};
const calculateTradePnl = (trade) => {
  const terminal = isTerminalStatus(trade.status);
  const entryRaw = trade.average_entry_price ?? trade.entry_price;
  const markRaw = terminal
    ? (trade.average_exit_price ?? trade.exit_price)
    : trade.last_price;
  const quantityRaw = trade.quantity;
  const entry = Number(entryRaw);
  const mark = Number(markRaw);
  const quantity = Number(quantityRaw);
  if (
    entryRaw === null || entryRaw === undefined || entryRaw === '' ||
    markRaw === null || markRaw === undefined || markRaw === '' ||
    !Number.isFinite(entry) || !Number.isFinite(mark) ||
    !Number.isFinite(quantity) || quantity < 0
  ) return null;
  const side = String(trade.direction || 'BUY').toUpperCase();
  if (side !== 'BUY' && side !== 'SELL') return null;
  return (mark - entry) * quantity * (side === 'SELL' ? -1 : 1);
};
const isTerminalStatus = (value) => ['CLOSED', 'CANCELLED', 'REJECTED', 'EXPIRED'].includes(String(value || '').toUpperCase());
const quoteFreshness = (trade) => {
  const raw = trade.last_market_data_at || trade.quote_received_at || trade.quote_timestamp || trade.last_quote_at;
  if (!raw) return { label: trade.quote_state === 'LIVE' ? 'Timestamp unavailable' : (trade.quote_state || 'No quote'), stale: true };
  const timestamp = new Date(raw).getTime();
  if (!Number.isFinite(timestamp)) return { label: 'Quote time unavailable', stale: true };
  const age = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  return { label: age > 30 ? `STALE · ${age}s` : `LIVE · ${age}s`, stale: age > 30 };
};
const csvCell = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
const formatTradeDuration = (trade, now = Date.now()) => {
  const startRaw = trade.entry_time || trade.created_at;
  const endRaw = isTerminalStatus(trade.status)
    ? (trade.closed_at || trade.auto_exit_at || trade.exit_at || trade.updated_at)
    : now;
  if (!startRaw || !endRaw) return '—';
  const start = new Date(startRaw).getTime();
  const end = typeof endRaw === 'number' ? endRaw : new Date(endRaw).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return '—';
  const totalSeconds = Math.floor((end - start) / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return days > 0
    ? `${days}d ${hours}h ${minutes}m`
    : hours > 0
      ? `${hours}h ${minutes}m ${seconds}s`
      : `${minutes}m ${seconds}s`;
};
const trailCount = (trade, field) => {
  const candidates = field === 'target'
    ? [trade.target_trail_count, trade.target_trailings, trade.target_trail_count_total, trade.target_trail_count]
    : [trade.stop_loss_trail_count, trade.sl_trail_count, trade.stop_loss_trailings, trade.sl_trailings];
  const count = candidates.find((value) => value !== null && value !== undefined && value !== '');
  const parsed = Number(count);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
};

export default function TradeTerminal({ onUnderlyingSelect }) {
  const [trades, setTrades] = useState([]);
  const [terminal, setTerminal] = useState({});
  const [mode, setMode] = useState('ALL');
  const [status, setStatus] = useState('OPEN');
  const [sourceFilter, setSourceFilter] = useState('ALL');
  const [underlyingFilter, setUnderlyingFilter] = useState('INDICES');
  const [symbolLetter, setSymbolLetter] = useState('ALL');
  const [selectedTradingDate, setSelectedTradingDate] = useState(() => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date()));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [closeTrade, setCloseTrade] = useState(null);
  const [editTrade, setEditTrade] = useState(null);
  const [editStopLoss, setEditStopLoss] = useState('');
  const [editTarget, setEditTarget] = useState('');
  const [editSaving, setEditSaving] = useState(false);
  const [detailsTrade, setDetailsTrade] = useState(null);
  const [sortConfig, setSortConfig] = useState({ key: 'underlying', direction: 'asc' });
  const [columnPreset, setColumnPreset] = useState('Basic');
  const [durationNow, setDurationNow] = useState(() => Date.now());
  const [closeOrderType, setCloseOrderType] = useState('MARKET');
  const [closeLimitPrice, setCloseLimitPrice] = useState('');
  const [symbolQuery, setSymbolQuery] = useState('');
  const [symbolExchange, setSymbolExchange] = useState('ALL');
  const [symbolType, setSymbolType] = useState('ALL');
  const [instrumentOptions, setInstrumentOptions] = useState([]);
  const [loadingInstruments, setLoadingInstruments] = useState(false);
  const [instrumentSearchError, setInstrumentSearchError] = useState('');
  const [saving, setSaving] = useState(false);
  const [requestKey, setRequestKey] = useState(() => crypto.randomUUID());
  const [form, setForm] = useState({ instrument_symbol: '', exchange: 'NFO', underlying: 'NIFTY', direction: 'BUY', quantity: '1', entry_price: '', stop_loss: '', target: '', strategy: 'Manual Paper Trade', notes: '' });

  useEffect(() => {
    const timer = window.setInterval(() => setDurationNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true); setError('');
    try {
      // Always load the complete canonical trade history. Mode, status and
      // date are presentation filters and must not truncate the underlying data.
      const result = await request('/trades');
      setTrades(result.trades || []); setTerminal(result.terminal || {});
    } catch (e) { setError(e.message || 'Unable to load canonical trade records.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    refresh();
    // WebSocket ticks are the primary update path. This silent cache sync is a
    // fallback for ticks cached before a trade subscription or a missed push event.
    let syncInFlight = false;
    const syncCachedQuotes = async () => {
      if (syncInFlight || document.visibilityState === 'hidden') return;
      syncInFlight = true;
      try {
        const result = await request('/trades');
        setTrades(result.trades || []);
        setTerminal(result.terminal || {});
      } catch {
        // Keep the current table visible; the next cycle or WebSocket can recover.
      } finally {
        syncInFlight = false;
      }
    };
    const quoteSyncTimer = window.setInterval(syncCachedQuotes, 2000);
    let socket;
    let reconnectTimer;
    let disposed = false;
    const connect = () => {
      if (disposed) return;
      socket = new WebSocket(`${WS_API}/api/v1/trades/stream`);
      socket.onmessage = (event) => {
        let message;
        try { message = JSON.parse(event.data); } catch { return; }
        if (message.type === 'snapshot') {
          setTrades(message.trades || []);
          setTerminal(message.terminal || {});
        } else if (message.type === 'trade_upsert' && message.trade) {
          if (message.terminal) setTerminal(message.terminal);
          setTrades((current) => {
            const index = current.findIndex((item) => item.trade_id === message.trade.trade_id);
            if (index < 0) return [message.trade, ...current];
            return current.map((item) => item.trade_id === message.trade.trade_id ? { ...item, ...message.trade } : item);
          });
        } else if (message.type === 'trade_quote' && message.trade) {
          setTrades((current) => current.map((item) => item.trade_id === message.trade_id ? { ...item, ...message.trade } : item));
        } else if (message.type === 'trade_status') {
          setTerminal(message.terminal || {});
        }
      };
      socket.onclose = () => {
        if (!disposed) reconnectTimer = window.setTimeout(connect, 1500);
      };
      socket.onerror = () => socket.close();
    };
    connect();
    return () => {
      disposed = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      window.clearInterval(quoteSyncTimer);
      if (socket) socket.close();
    };
  }, [refresh]);

  useEffect(() => {
    if (!showCreate || symbolQuery.trim().length < 2) {
      setInstrumentOptions([]);
      setInstrumentSearchError('');
      setLoadingInstruments(false);
      return undefined;
    }
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setLoadingInstruments(true);
      setInstrumentSearchError('');
      try {
        const params = new URLSearchParams({ q: symbolQuery.trim(), limit: '100' });
        if (symbolExchange !== 'ALL') params.set('exchange', symbolExchange);
        if (symbolType !== 'ALL') params.set('instrument_type', symbolType);
        const result = await request('/trades/instruments?' + params.toString());
        if (!cancelled) setInstrumentOptions(result.instruments || []);
      } catch (e) {
        if (!cancelled) {
          setInstrumentOptions([]);
          setInstrumentSearchError(e.message || 'Unable to search instruments.');
        }
      } finally {
        if (!cancelled) setLoadingInstruments(false);
      }
    }, 250);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [showCreate, symbolQuery, symbolExchange, symbolType]);

  const selectInstrument = (instrument) => {
    const symbol = instrument.tradingsymbol;
    const underlying = ['NIFTY','BANKNIFTY','FINNIFTY','MIDCPNIFTY','SENSEX','BANKEX'].find((index) => symbol.toUpperCase().startsWith(index)) ||
      (instrument.instrument_type === 'EQ' ? 'OTHER' : form.underlying);
    setForm((current) => ({ ...current, instrument_symbol: symbol, exchange: instrument.exchange, underlying }));
    setSymbolQuery(symbol);
    setInstrumentOptions([]);
  };

  const sources = [...new Set(trades.map((trade) => trade.source).filter(Boolean))].sort();
  const indiaDateKey = (value) => {
    const date = value instanceof Date ? value : new Date(value);
    if (!Number.isFinite(date.getTime())) return '';
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(date);
  };
  const todayKey = indiaDateKey(new Date());
  const selectedDateObject = new Date(`${selectedTradingDate}T00:00:00Z`);
  const selectedTradingDateLabel = Number.isFinite(selectedDateObject.getTime())
    ? new Intl.DateTimeFormat('en-IN', { timeZone: 'UTC', weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }).format(selectedDateObject)
    : selectedTradingDate;
  const shiftTradingDate = (days) => {
    const next = new Date(`${selectedTradingDate}T00:00:00Z`);
    next.setUTCDate(next.getUTCDate() + days);
    const nextKey = next.toISOString().slice(0, 10);
    if (nextKey <= todayKey) setSelectedTradingDate(nextKey);
  };
  const tradesMatchingBaseFilters = trades.filter((trade) => {
    const createdKey = indiaDateKey(trade.created_at || trade.updated_at);
    const normalizedSource = String(trade.source || '').toUpperCase();
    const sourceMatches = sourceFilter === 'ALL' || normalizedSource === sourceFilter ||
      (sourceFilter === 'AUTOTRENDER' && normalizedSource.includes('AUTO'));
    const statusValue = String(trade.status || '').toUpperCase();
    const statusMatches = status === 'ALL' || (status === 'OPEN' && !['CLOSED','CANCELLED','REJECTED','EXPIRED'].includes(statusValue)) || statusValue === status;
    return (mode === 'ALL' || trade.execution_mode === mode) && statusMatches && sourceMatches && createdKey === selectedTradingDate;
  });
  const underlyings = [...new Set(tradesMatchingBaseFilters.map((trade) => String(trade.underlying || '').trim()).filter(Boolean))].sort();
  const tradesMatchingOtherFilters = tradesMatchingBaseFilters.filter((trade) => {
    const underlyingValue = String(trade.underlying || '').toUpperCase();
    return underlyingFilter === 'ALL' ||
      (underlyingFilter === 'INDICES' && ['NIFTY','BANKNIFTY','FINNIFTY','SENSEX'].includes(underlyingValue)) ||
      (underlyingFilter === 'OTHER'
        ? !['NIFTY','BANKNIFTY','FINNIFTY','SENSEX'].includes(underlyingValue)
        : String(trade.underlying || '') === underlyingFilter);
  });
  const symbolLetters = [...new Set(tradesMatchingOtherFilters.flatMap((trade) =>
    [trade.instrument_symbol, trade.underlying]
      .map((value) => String(value || '').trim().charAt(0).toUpperCase())
      .filter((letter) => /^[A-Z]$/.test(letter))
  ))].sort();
  const visibleTrades = tradesMatchingOtherFilters.filter((trade) =>
    symbolLetter === 'ALL' ||
    String(trade.instrument_symbol || '').trim().toUpperCase().startsWith(symbolLetter) ||
    String(trade.underlying || '').trim().toUpperCase().startsWith(symbolLetter)
  );

  const create = async (event) => {
    event.preventDefault(); setSaving(true); setError('');
    try {
      const payload = { ...form, idempotency_key: requestKey, execution_mode: 'PAPER', source: 'MANUAL', quantity: Number(form.quantity) };
      for (const key of ['entry_price', 'stop_loss', 'target']) payload[key] = payload[key] === '' ? null : Number(payload[key]);
      const result = await request('/trades', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      setShowCreate(false);
      setRequestKey(crypto.randomUUID());
      setForm({ instrument_symbol: '', exchange: 'NFO', underlying: 'NIFTY', direction: 'BUY', quantity: '1', entry_price: '', stop_loss: '', target: '', strategy: 'Manual Paper Trade', notes: '' });
      await refresh();
      if (result.trade?.persistence_state === 'DEGRADED') setError('Trade is not durably persisted; check database connectivity.');
    } catch (e) { setError(e.message || 'Trade could not be saved.'); }
    finally { setSaving(false); }
  };

  const reconcileLive = async () => {
    setLoading(true); setError('');
    try {
      const result = await request('/trades/reconcile-live', { method: 'POST' });
      await refresh();
      const r = result.reconciliation || {};
      window.alert(`Kite reconciliation complete: ${r.created || 0} created, ${r.updated || 0} updated, ${r.closed || 0} closed.`);
    } catch (e) { setError(e.message || 'Live-position reconciliation failed.'); }
    finally { setLoading(false); }
  };

  const openEditDialog = (trade) => {
    setEditTrade(trade);
    setEditStopLoss(trade.stop_loss == null ? '' : String(trade.stop_loss));
    setEditTarget(trade.target == null ? '' : String(trade.target));
    setError('');
  };

  const saveTradeLevels = async () => {
    if (!editTrade || editSaving) return;
    const latest = trades.find((item) => item.trade_id === editTrade.trade_id) || editTrade;
    const sl = Number(editStopLoss);
    const target = Number(editTarget);
    if (!editStopLoss.trim() || !Number.isFinite(sl) || sl <= 0) { setError('Enter a valid positive Stop Loss.'); return; }
    if (!editTarget.trim() || !Number.isFinite(target) || target <= 0) { setError('Enter a valid positive Target.'); return; }
    const rawLtp = latest.last_price;
    const ltp = rawLtp === null || rawLtp === undefined || rawLtp === '' ? NaN : Number(rawLtp);
    const isBuy = String(latest.direction || 'BUY').toUpperCase() === 'BUY';
    if (Number.isFinite(ltp) && ltp > 0) {
      const valid = isBuy ? sl < ltp && target > ltp : target < ltp && sl > ltp;
      if (!valid) {
        setError(isBuy
          ? 'For a BUY trade, Stop Loss must be below the current market price and Target must be above it.'
          : 'For a SELL trade, Target must be below the current market price and Stop Loss must be above it.');
        return;
      }
    }
    const changes = {};
    if (Number(latest.stop_loss ?? 0) !== sl) changes.stop_loss = sl;
    if (Number(latest.target ?? 0) !== target) changes.target = target;
    if (!Object.keys(changes).length) { setEditTrade(null); return; }
    setEditSaving(true);
    setError('');
    try {
      await request('/trades/' + encodeURIComponent(latest.trade_id), {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changes),
      });
      setEditTrade(null);
      await refresh();
    } catch (e) {
      setError(e.message || 'Could not update Stop Loss and Target.');
    } finally {
      setEditSaving(false);
    }
  };

  const openCloseDialog = (trade) => {
    setCloseTrade(trade);
    setCloseOrderType('MARKET');
    setCloseLimitPrice('');
    setError('');
  };

  const updateStatus = async () => {
    if (!closeTrade) return;
    // The close dialog initially receives a snapshot of the row. Prefer the
    // latest trade state so WebSocket/cache-sync quote updates are not lost
    // while the dialog is open.
    const trade = trades.find((item) => item.trade_id === closeTrade.trade_id) || closeTrade;
    const cachedLtp = trade.last_price === null || trade.last_price === undefined || trade.last_price === ''
      ? NaN
      : Number(trade.last_price);
    // If no quote is available, let the user manually enter the simulated
    // exit price instead of trapping the paper trade behind the missing LTP.
    const useManualFallback = closeOrderType === 'MARKET' && (!Number.isFinite(cachedLtp) || cachedLtp <= 0);
    const exitPrice = closeOrderType === 'MARKET' && !useManualFallback
      ? cachedLtp
      : Number(closeLimitPrice);
    if (!Number.isFinite(exitPrice) || exitPrice <= 0) {
      setError(closeOrderType === 'MARKET'
        ? 'Enter a manual exit price below because no quote is currently available.'
        : 'Enter a valid positive limit price.');
      return;
    }
    const rawEntryPrice = trade.average_entry_price ?? trade.entry_price;
    const entryPrice = rawEntryPrice === null || rawEntryPrice === undefined || rawEntryPrice === '' ? NaN : Number(rawEntryPrice);
    const qty = Number(trade.quantity ?? 0);
    const directionFactor = String(trade.direction).toUpperCase() === 'SELL' ? -1 : 1;
    const changes = {
      status: 'CLOSED', exit_price: exitPrice, average_exit_price: exitPrice,
      quantity: qty,
      exit_reason: 'Manual paper close',
      exit_method: closeOrderType === 'MARKET' && Number.isFinite(cachedLtp) && cachedLtp > 0
        ? 'PAPER_MARKET_SIMULATION'
        : closeOrderType === 'LIMIT' ? 'PAPER_LIMIT_SIMULATION' : 'PAPER_MANUAL_PRICE_SIMULATION',
    };
    try {
      await request(`/trades/${encodeURIComponent(trade.trade_id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(changes) });
      setCloseTrade(null);
      await refresh();
    } catch (e) { setError(e.message || 'Trade update failed.'); }
  };

  const getTradeSortValue = (trade, key) => {
    if (key === 'duration') {
      const startRaw = trade.entry_time || trade.created_at;
      const endRaw = isTerminalStatus(trade.status)
        ? (trade.closed_at || trade.auto_exit_at || trade.exit_at || trade.updated_at)
        : durationNow;
      const start = startRaw ? new Date(startRaw).getTime() : NaN;
      const end = typeof endRaw === 'number' ? endRaw : new Date(endRaw).getTime();
      return Number.isFinite(start) && Number.isFinite(end) ? Math.max(0, end - start) : null;
    }
    if (key === 'average_entry_price') return trade.average_entry_price ?? trade.entry_price;
    if (key === 'average_exit_price') return trade.average_exit_price ?? trade.exit_price;
    if (key === 'display_pnl') return calculateTradePnl(trade);
    return trade[key];
  };
  const numericSortKeys = new Set([
    'quantity', 'entry_price', 'average_entry_price', 'last_price', 'stop_loss',
    'target', 'average_exit_price', 'exit_price', 'display_pnl', 'duration',
    'created_at', 'updated_at',
  ]);
  const displayedTrades = visibleTrades.map((trade) => ({ ...trade, display_pnl: calculateTradePnl(trade) })).sort((a, b) => {
    const left = getTradeSortValue(a, sortConfig.key);
    const right = getTradeSortValue(b, sortConfig.key);
    let comparison;
    if (numericSortKeys.has(sortConfig.key)) {
      const leftNumber = left === null || left === undefined || left === '' ? Number.NEGATIVE_INFINITY : (
        typeof left === 'number' ? left : new Date(left).getTime()
      );
      const rightNumber = right === null || right === undefined || right === '' ? Number.NEGATIVE_INFINITY : (
        typeof right === 'number' ? right : new Date(right).getTime()
      );
      comparison = leftNumber - rightNumber;
    } else {
      comparison = String(left ?? '').localeCompare(String(right ?? ''), undefined, { numeric: true, sensitivity: 'base' });
    }
    return sortConfig.direction === 'asc' ? comparison : -comparison;
  });
  const toggleSort = (key) => setSortConfig((current) => ({ key, direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc' }));
  const exportVisibleTrades = () => {
    const columns = [
      ['Trade ID', 'trade_id'], ['Mode', 'execution_mode'], ['Underlying', 'underlying'], ['Instrument', 'instrument_symbol'],
      ['Exchange', 'exchange'], ['Side', 'direction'], ['Qty', 'quantity'],
      ['Last Price', 'last_price'], ['Entry Price', 'average_entry_price'], ['Stop Loss', 'stop_loss'], ['Target', 'target'],
      ['Calculated P&L', 'display_pnl'], ['Exit Price', 'average_exit_price'],
      ['Exit Reason', 'exit_reason'], ['Exit Method', 'exit_method'], ['Status', 'status'], ['Source', 'source'],
      ['Strategy', 'strategy'], ['Trailing Strategy', 'trailing_strategy'], ['Notes', 'notes'], ['Created At', 'created_at'], ['Updated At', 'updated_at'],
    ];
    const csv = [columns.map(([label]) => csvCell(label)).join(','), ...displayedTrades.map((trade) => columns.map(([, key]) => {
      const value = key === 'display_pnl' ? trade.display_pnl : trade[key];
      return csvCell(value ?? '');
    }).join(','))].join('\r\n');
    const blob = new Blob(['\ufeff', csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `trade-terminal-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const pnlSummary = visibleTrades.reduce((summary, trade) => {
    const total = calculateTradePnl(trade);
    if (total === null) return summary;
    if (total > 0) summary.profit += total;
    if (total < 0) summary.loss += Math.abs(total);
    summary.net += total;
    return summary;
  }, { profit: 0, loss: 0, net: 0 });

  return <section className="trade-terminal-page">
    <div className="trade-terminal-overview panel"><div className="trade-terminal-actions"><button className="button secondary" onClick={exportVisibleTrades} disabled={!displayedTrades.length}>Export CSV ({displayedTrades.length})</button><button className="button secondary" onClick={reconcileLive} disabled={loading}>{loading ? 'Syncing…' : 'Sync Live Positions'}</button><button className="button primary" onClick={() => { setShowCreate(true); setSymbolQuery(''); setSymbolExchange('ALL'); setSymbolType('ALL'); }}>+ New Paper Trade</button></div>
    <div className="trade-terminal-metrics" style={{ gap: 8 }}>
      <div className="metric" style={{ padding: "8px 10px", minHeight: 0 }}><span style={{ fontSize: "0.75rem" }}>Filtered trades</span><strong style={{ fontSize: "1rem" }}>{fmt(visibleTrades.length)}</strong></div>
      <div className="metric" style={{ padding: "8px 10px", minHeight: 0 }}><span style={{ fontSize: "0.75rem" }}>Open in filter</span><strong style={{ fontSize: "1rem" }}>{fmt(visibleTrades.filter((trade) => !isTerminalStatus(trade.status)).length)}</strong></div>

      <div className="metric" style={{ padding: "8px 10px", minHeight: 0 }}><span style={{ fontSize: "0.75rem" }}>Total Profit</span><strong style={{ fontSize: "1rem" }} className="holding-pnl-positive">{formatPnl(pnlSummary.profit)}</strong></div>
      <div className="metric" style={{ padding: "8px 10px", minHeight: 0 }}><span style={{ fontSize: "0.75rem" }}>Total Loss</span><strong style={{ fontSize: "1rem" }} className="holding-pnl-negative">{formatPnl(-pnlSummary.loss)}</strong></div>
      <div className="metric" style={{ padding: "8px 10px", minHeight: 0 }}><span style={{ fontSize: "0.75rem" }}>Net P&amp;L</span><strong style={{ fontSize: "1rem" }} className={pnlSummary.net >= 0 ? 'holding-pnl-positive' : 'holding-pnl-negative'}>{formatPnl(pnlSummary.net)}</strong></div>
    </div>
    </div>
    {error && <div className="error-banner"><strong>Trade terminal issue</strong><span>{error}</span><button onClick={() => setError('')} aria-label="Dismiss error">×</button></div>}
    {terminal.persistence_degraded && <div className="trade-persistence-warning">Database persistence is degraded. Do not assume cache-only changes are durable. {terminal.persistence_error || ''}</div>}
    {detailsTrade && <div className="trade-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setDetailsTrade(null); }}>
      <div className="panel trade-create-form trade-create-modal trade-details-modal" role="dialog" aria-modal="true" aria-labelledby="trade-details-title">
        <div className="trade-modal-heading"><div><h2 id="trade-details-title">Trade details</h2><p>{detailsTrade.exchange || '—'}:{detailsTrade.instrument_symbol} · {detailsTrade.execution_mode} · {detailsTrade.status}</p></div><button className="button secondary" type="button" onClick={() => setDetailsTrade(null)}>✕</button></div>
        <div className="trade-details-grid">
          {[
            ['Direction', detailsTrade.direction], ['Qty', detailsTrade.quantity],
            ['Entry price', detailsTrade.average_entry_price ?? detailsTrade.entry_price], ['Last price', detailsTrade.last_price],
            ['Trade duration', formatTradeDuration(detailsTrade, durationNow)], ['Stop loss', detailsTrade.stop_loss], ['Target', detailsTrade.target], ['Calculated P&L', calculateTradePnl(detailsTrade)], ['Exit price', detailsTrade.average_exit_price ?? detailsTrade.exit_price],
            ['Exit reason', detailsTrade.exit_reason], ['Exit method', detailsTrade.exit_method], ['Source', detailsTrade.source],
            ['Strategy', detailsTrade.strategy], ['Trailing Strategy', detailsTrade.trailing_strategy], ['Quote status', quoteFreshness(detailsTrade).label],
            ['Created', detailsTrade.created_at ? new Date(detailsTrade.created_at).toLocaleString() : '—'],
            ['Updated', detailsTrade.updated_at ? new Date(detailsTrade.updated_at).toLocaleString() : '—'],
          ].map(([label, value]) => <div className="trade-detail-item" key={label}><span>{label}</span><strong>{label === 'Calculated P&L' ? formatPnl(value) : fmt(value)}</strong></div>)}
        </div>
        {detailsTrade.notes && <div className="trade-details-notes"><span>Notes</span><p>{detailsTrade.notes}</p></div>}
        {detailsTrade.execution_mode === 'PAPER' && <p className="trade-paper-notice">Paper trade only. Closing a trade records a simulated exit; no broker order is placed.</p>}
      </div>
    </div>}
    {editTrade && <div className="trade-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !editSaving) setEditTrade(null); }}>
      <div className="panel trade-create-form trade-create-modal" role="dialog" aria-modal="true" aria-labelledby="edit-trade-title" style={{ width: 'min(860px, 96vw)', maxWidth: '860px' }}>
        <div className="trade-modal-heading"><div><h2 id="edit-trade-title">Edit Trade</h2><p>{editTrade.exchange || '—'}:{editTrade.instrument_symbol}</p></div><button className="button secondary" type="button" onClick={() => setEditTrade(null)} disabled={editSaving}>✕</button></div>
        <div className="trade-details-grid" style={{ gridTemplateColumns: 'repeat(5, minmax(0, 1fr))', marginBottom: 20 }}>
          {[['Mode', editTrade.execution_mode], ['Underlying', editTrade.underlying], ['Instrument', editTrade.instrument_symbol], ['Side', editTrade.direction], ['Qty', editTrade.quantity]].map(([label, value]) => <div className="trade-detail-item" key={label}><span>{label}</span><strong>{fmt(value)}</strong></div>)}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 16 }}>
          <section style={{ border: '1px solid #e6a0a0', borderLeft: '5px solid #c62828', borderRadius: 10, padding: 16, background: 'rgba(198,40,40,0.055)', minWidth: 0 }}>
            <h3 style={{ margin: '0 0 6px', color: '#b42323' }}>Stop Loss (SL)</h3>
            <p style={{ margin: '0 0 12px', color: 'var(--muted, #64748b)', fontSize: 13 }}>Set a new stop loss for this trade.</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
              <div><span style={{ display: 'block', fontSize: 12, color: 'var(--muted, #64748b)' }}>Current SL</span><strong style={{ fontSize: 20 }}>{fmt(editTrade.stop_loss)}</strong></div>
              <div><span style={{ display: 'block', fontSize: 12, color: 'var(--muted, #64748b)' }}>Current Market Price</span><strong style={{ fontSize: 20 }}>{fmt(trades.find((item) => item.trade_id === editTrade.trade_id)?.last_price ?? editTrade.last_price)}</strong></div>
            </div>
            <label className="settings-control"><span>New SL</span><input type="number" min="0.01" step="any" value={editStopLoss} onChange={(event) => setEditStopLoss(event.target.value)} disabled={editSaving} /></label>
            <p style={{ margin: '10px 0 0', fontSize: 12, color: 'var(--muted, #64748b)' }}>SL trail count (continues): {fmt(editTrade.stop_loss_trail_count ?? 0)}</p>
          </section>
          <section style={{ border: '1px solid #8bc9a7', borderLeft: '5px solid #16804a', borderRadius: 10, padding: 16, background: 'rgba(22,128,74,0.055)', minWidth: 0 }}>
            <h3 style={{ margin: '0 0 6px', color: '#16804a' }}>Target</h3>
            <p style={{ margin: '0 0 12px', color: 'var(--muted, #64748b)', fontSize: 13 }}>Set a new target for this trade.</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
              <div><span style={{ display: 'block', fontSize: 12, color: 'var(--muted, #64748b)' }}>Current Target</span><strong style={{ fontSize: 20 }}>{fmt(editTrade.target)}</strong></div>
              <div><span style={{ display: 'block', fontSize: 12, color: 'var(--muted, #64748b)' }}>Current Market Price</span><strong style={{ fontSize: 20 }}>{fmt(trades.find((item) => item.trade_id === editTrade.trade_id)?.last_price ?? editTrade.last_price)}</strong></div>
            </div>
            <label className="settings-control"><span>New Target</span><input type="number" min="0.01" step="any" value={editTarget} onChange={(event) => setEditTarget(event.target.value)} disabled={editSaving} /></label>
            <p style={{ margin: '10px 0 0', fontSize: 12, color: 'var(--muted, #64748b)' }}>Target trail count (continues): {fmt(editTrade.target_trail_count ?? 0)}</p>
          </section>
        </div>
        <div style={{ marginTop: 16, padding: 14, borderRadius: 9, background: 'rgba(59,130,246,0.10)', fontSize: 13, lineHeight: 1.6 }}>
          <strong>Editing rules</strong><br />
          Only Stop Loss and Target can be changed for active PAPER trades. Current market price is shown for reference. The existing trailing strategy and trail counts are preserved.
        </div>
        {error && <div className="error-banner" role="alert" style={{ marginTop: 12 }}><span>{error}</span></div>}
        <div className="settings-actions" style={{ marginTop: 18 }}><span className="trade-paper-label">PAPER MODE · no broker order will be placed</span><button className="button secondary" type="button" onClick={() => setEditTrade(null)} disabled={editSaving}>Cancel</button><button className="button primary" type="button" onClick={saveTradeLevels} disabled={editSaving}>{editSaving ? 'Updating…' : 'Update'}</button></div>
      </div>
    </div>}
    {closeTrade && <div className="trade-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setCloseTrade(null); }}>
      <div className="panel trade-create-form trade-create-modal" role="dialog" aria-modal="true" aria-labelledby="close-trade-title">
        <div className="trade-modal-heading"><div><h2 id="close-trade-title">Close paper trade</h2><p>{closeTrade.instrument_symbol} · {fmt(closeTrade.quantity)} units</p></div><button className="button secondary" type="button" onClick={() => setCloseTrade(null)}>✕</button></div>
        <div className="trade-close-order-choices">
          <span className="trade-filter-label">Exit order type</span>
          <div className="trade-filter-buttons">
            <button className={closeOrderType === 'MARKET' ? 'trade-filter-button active' : 'trade-filter-button'} type="button" onClick={() => setCloseOrderType('MARKET')}>Market Price</button>
            <button className={closeOrderType === 'LIMIT' ? 'trade-filter-button active' : 'trade-filter-button'} type="button" onClick={() => setCloseOrderType('LIMIT')}>Limit Price</button>
          </div>
        </div>
        {closeOrderType === 'MARKET' && Number.isFinite(Number(trades.find((item) => item.trade_id === closeTrade.trade_id)?.last_price ?? closeTrade.last_price)) && Number(trades.find((item) => item.trade_id === closeTrade.trade_id)?.last_price ?? closeTrade.last_price) > 0
          ? <div className="trade-selected-instrument">Simulated exit price from latest cached quote: <strong>{fmt(trades.find((item) => item.trade_id === closeTrade.trade_id)?.last_price ?? closeTrade.last_price)}</strong><p className="trade-paper-notice">This records a simulated exit; no broker order is placed.</p></div>
          : <label className="settings-control"><span>{closeOrderType === 'MARKET' ? 'Manual exit price (quote unavailable) *' : 'Limit price *'}</span><input autoFocus type="number" min="0.01" step="any" required value={closeLimitPrice} onChange={(e) => setCloseLimitPrice(e.target.value)} placeholder="Enter exit price" />{closeOrderType === 'MARKET' && <p className="trade-paper-notice">No cached LTP is available. Enter the price at which you want to record this paper-trade exit.</p>}</label>}
        <div className="settings-actions"><span className="trade-paper-label">PAPER MODE · no broker order will be placed</span><button className="button secondary" type="button" onClick={() => setCloseTrade(null)}>Cancel</button><button className="button primary" type="button" onClick={updateStatus}>Confirm close</button></div>
      </div>
    </div>}
    {showCreate && <div className="trade-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !saving) setShowCreate(false); }}>
      <form className="panel trade-create-form trade-create-modal" onSubmit={create}>
      <div className="trade-modal-heading"><div><h2>New paper trade</h2><p>Search the Kite instrument master and select a symbol.</p></div><button className="button secondary" type="button" onClick={() => setShowCreate(false)} disabled={saving}>✕</button></div>
      <div className="trade-instrument-picker">
        <label className="settings-control"><span>Search symbols</span><input autoFocus value={symbolQuery} onChange={(e) => setSymbolQuery(e.target.value)} placeholder="Type a symbol or company name (e.g. RELIANCE, NIFTY)" /></label>
        <div className="trade-instrument-filters">
          <label className="settings-control"><span>Exchange</span><select value={symbolExchange} onChange={(e) => setSymbolExchange(e.target.value)}><option value="ALL">All exchanges</option><option value="NSE">NSE</option><option value="NFO">NFO</option><option value="BSE">BSE</option><option value="BFO">BFO</option><option value="CDS">CDS</option><option value="MCX">MCX</option></select></label>
          <label className="settings-control"><span>Instrument type</span><select value={symbolType} onChange={(e) => setSymbolType(e.target.value)}><option value="ALL">All types</option><option value="EQ">Equity (EQ)</option><option value="CE">Call option (CE)</option><option value="PE">Put option (PE)</option><option value="FUT">Futures (FUT)</option></select></label>
        </div>
        <div className="trade-instrument-results" aria-live="polite">
          {loadingInstruments && <div className="trade-instrument-empty">Searching Kite instruments…</div>}
          {!loadingInstruments && instrumentSearchError && <div className="trade-instrument-empty negative">{instrumentSearchError}</div>}
          {!loadingInstruments && !instrumentSearchError && symbolQuery.trim().length < 2 && <div className="trade-instrument-empty">Enter at least two characters to search.</div>}
          {!loadingInstruments && !instrumentSearchError && symbolQuery.trim().length >= 2 && !instrumentOptions.length && <div className="trade-instrument-empty">No matching instruments. Try another symbol or filter.</div>}
          {instrumentOptions.map((instrument) => <button key={instrument.instrument_token} type="button" className={'trade-instrument-option' + (form.instrument_symbol === instrument.tradingsymbol && form.exchange === instrument.exchange ? ' selected' : '')} onClick={() => selectInstrument(instrument)}>
            <span className="trade-instrument-main"><strong>{instrument.tradingsymbol}</strong><small>{instrument.name || instrument.segment || instrument.instrument_type || 'Kite instrument'}</small></span>
            <span className="trade-instrument-meta"><strong>{instrument.exchange}</strong><small>{instrument.instrument_type || instrument.segment || '—'}{instrument.expiry ? ' · ' + instrument.expiry : ''}</small></span>
          </button>)}
        </div>
        <div className="trade-selected-instrument">{form.instrument_symbol ? <>Selected: <strong>{form.exchange}:{form.instrument_symbol}</strong></> : 'Select a symbol from the search results to continue.'}</div>
      </div>
      <div className="settings-grid">
        <label className="settings-control"><span>Instrument symbol *</span><input required readOnly value={form.instrument_symbol} placeholder="Select a symbol above" /></label>
        <label className="settings-control"><span>Exchange</span><select value={form.exchange} onChange={(e) => setForm({ ...form, exchange: e.target.value })}>{[['NSE','NSE · Stocks'],['NFO','NFO · Options'],['BSE','BSE · Stocks'],['BFO','BFO · Options']].map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label>
        <label className="settings-control"><span>Underlying / index</span><select value={form.underlying} onChange={(e) => setForm({ ...form, underlying: e.target.value })}>{['NIFTY','BANKNIFTY','FINNIFTY','SENSEX','OTHER'].map((x) => <option key={x}>{x}</option>)}</select></label>
        <label className="settings-control"><span>Direction</span><select value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })}><option>BUY</option><option>SELL</option></select></label>
        <label className="settings-control"><span>Quantity *</span><input type="number" min="1" required value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></label>
        <label className="settings-control"><span>Entry price</span><input type="number" min="0" step="any" value={form.entry_price} onChange={(e) => setForm({ ...form, entry_price: e.target.value })} /></label>
        <label className="settings-control"><span>Stop loss</span><input type="number" min="0" step="any" value={form.stop_loss} onChange={(e) => setForm({ ...form, stop_loss: e.target.value })} /></label>
        <label className="settings-control"><span>Target</span><input type="number" min="0" step="any" value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })} /></label>
        <label className="settings-control"><span>Strategy / source label</span><input value={form.strategy} onChange={(e) => setForm({ ...form, strategy: e.target.value })} /></label>
        <label className="settings-control trade-notes-field"><span>Notes</span><input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} maxLength="2000" /></label>
      </div><div className="settings-actions"><span className="trade-paper-label">PAPER MODE · no broker order will be placed</span><button className="button primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create paper trade'}</button></div>
    </form></div>}
    <div className="trade-column-presets">
      <span className="trade-filter-label">Columns</span>
      <div className="trade-filter-buttons">
        <button type="button" className={columnPreset === 'Basic' ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setColumnPreset('Basic')}>Basic</button>
        <button type="button" className={columnPreset === 'AutoTrender' ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setColumnPreset('AutoTrender')}>AutoTrender</button>
        <button type="button" className={columnPreset === 'Detailed' ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setColumnPreset('Detailed')}>Detailed</button>
      </div>
    </div>
    <section className="panel trade-date-filter-panel">
    <div className="trade-date-navigator" aria-label="Select trading date">
      <button type="button" className="trade-date-nav-button" aria-label="Previous trading date" onClick={() => shiftTradingDate(-1)}>‹</button>
      <div className="trade-date-navigator-label">
        <span>SELECTED TRADING DATE</span>
        <strong>{selectedTradingDateLabel}</strong>
      </div>
      <button type="button" className="trade-date-nav-button" aria-label="Next trading date" onClick={() => shiftTradingDate(1)} disabled={selectedTradingDate >= todayKey}>›</button>
    </div>
    <div className="trade-terminal-filters">
      <div className="trade-filter-group"><span className="trade-filter-label">Mode</span><div className="trade-filter-buttons">{[['ALL','All'],['PAPER','Paper'],['LIVE','Live']].map(([value,label]) => <button key={value} type="button" className={mode === value ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setMode(value)}>{label}</button>)}</div></div>
      <div className="trade-filter-group"><span className="trade-filter-label">Status</span><div className="trade-filter-buttons">{[['ALL','All'],['OPEN','Open'],['CLOSED','Closed'],['CANCELLED','Cancelled']].map(([value,label]) => <button key={value} type="button" className={status === value ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setStatus(value)}>{label}</button>)}</div></div>
      <div className="trade-filter-group"><span className="trade-filter-label">Source</span><div className="trade-filter-buttons">{[['ALL','All'],...['AUTOTRENDER','MANUAL','KITE'].map(value => [value, value === 'AUTOTRENDER' ? 'AutoTrender' : value.charAt(0)+value.slice(1).toLowerCase()])].map(([value,label]) => <button key={value} type="button" className={sourceFilter === value ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setSourceFilter(value)}>{label}</button>)}</div></div>
      <div className="trade-filter-group"><span className="trade-filter-label">Underlying</span><div className="trade-filter-buttons">{[['ALL','All'],['INDICES','Indices'],...underlyings.filter(x => !['NIFTY','BANKNIFTY','FINNIFTY','SENSEX'].includes(x)).map(x => [x,x])].map(([value,label]) => <button key={value} type="button" className={underlyingFilter === value ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setUnderlyingFilter(value)}>{label}</button>)}</div></div>
      <div className="trade-filter-group trade-symbol-letter-filter"><span className="trade-filter-label">Symbol</span><div className="trade-filter-buttons">{[['ALL','All'],...symbolLetters.map((letter) => [letter,letter])].map(([value,label]) => <button key={value} type="button" className={symbolLetter === value ? 'trade-filter-button active' : 'trade-filter-button'} onClick={() => setSymbolLetter(value)}>{label}</button>)}</div></div>
      
    </div>
    </section>
    <section className="panel trade-terminal-table-panel"><div className="table-scroll trade-terminal-table-scroll"><table className="kite-data-table trade-terminal-table"><thead><tr>{([... [['execution_mode','Mode'],['underlying','Underlying'],['instrument_symbol','Instrument'],['direction','Side'],['quantity','Qty'],['average_entry_price','Entry'],...(columnPreset === 'Detailed' ? [['duration','Duration']] : []),['last_price','Last price'],['stop_loss','SL'],['target','Target'],['display_pnl','P&L'],['average_exit_price','Exit price'],['status','Status']], ...(columnPreset === 'Basic' ? [['trailing_strategy','Trailing Strategy']] : columnPreset === 'AutoTrender' ? [['source','Source'],['strategy','Strategy'],['trailing_strategy','Trailing Strategy']] : [['source','Source'],['strategy','Strategy'],['trailing_strategy','Trailing Strategy'],['updated_at','Updated']])]).map(([key,label]) => <th key={key}><button type="button" className="trade-sort-header" onClick={() => toggleSort(key)}>{label}{sortConfig.key === key ? (sortConfig.direction === 'asc' ? ' ↑' : ' ↓') : ''}</button></th>)}<th>Action</th></tr></thead><tbody>
      {displayedTrades.map((trade) => { return <tr key={trade.trade_id}><td><span className={'trade-mode-pill ' + String(trade.execution_mode).toLowerCase()}>{trade.execution_mode}</span></td><td>{['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'SENSEX'].includes(String(trade.underlying || '').trim().toUpperCase()) ? <button type="button" className="trade-symbol-link" title={`Open ${String(trade.underlying).toUpperCase()} in AutoTrender`} onClick={() => onUnderlyingSelect?.(trade.underlying)}>{fmt(trade.underlying)}</button> : fmt(trade.underlying)}</td><td><button type="button" className="trade-symbol-link" onClick={() => setDetailsTrade(trade)}>{fmt(trade.instrument_symbol)}</button></td><td>{fmt(trade.direction)}</td><td>{fmt(trade.quantity)}</td><td>{fmt(trade.average_entry_price ?? trade.entry_price)}</td>{columnPreset === 'Detailed' && <td title={`Entry: ${trade.entry_time || trade.created_at || 'unknown'}; End: ${isTerminalStatus(trade.status) ? (trade.closed_at || trade.auto_exit_at || trade.exit_at || trade.updated_at || 'unknown') : 'now'}`}>{formatTradeDuration(trade, durationNow)}</td>}<td>{fmt(trade.last_price)}</td><td><span className="trade-trail-value">{fmt(trade.stop_loss)}{trailCount(trade, 'stop_loss') > 0 && <sub title={`Stop-loss trailed ${trailCount(trade, 'stop_loss')} times`}>{trailCount(trade, 'stop_loss')}</sub>}</span></td><td><span className="trade-trail-value">{fmt(trade.target)}{trailCount(trade, 'target') > 0 && <sub title={`Target trailed ${trailCount(trade, 'target')} times`}>{trailCount(trade, 'target')}</sub>}</span></td><td className={trade.display_pnl === null ? 'holding-pnl-zero' : trade.display_pnl > 0 ? 'holding-pnl-positive' : trade.display_pnl < 0 ? 'holding-pnl-negative' : 'holding-pnl-zero'}>{formatPnl(trade.display_pnl)}</td><td>{fmt(trade.average_exit_price ?? trade.exit_price)}</td><td>{fmt(trade.status)}</td>{(columnPreset === 'Basic' ? [trade.trailing_strategy] : columnPreset === 'AutoTrender' ? [trade.source, trade.strategy, trade.trailing_strategy] : [trade.source, trade.strategy, trade.trailing_strategy, trade.updated_at ? new Date(trade.updated_at).toLocaleString() : '—']).map((value,index) => <td key={index}>{fmt(value)}</td>)}<td>{trade.execution_mode === 'PAPER' && !isTerminalStatus(trade.status) && <><button type="button" className="button secondary trade-close-button" onClick={() => openEditDialog(trade)}>Edit</button><button type="button" className="button secondary trade-close-button" onClick={() => openCloseDialog(trade)}>Close</button></>}</td></tr> })}
      {!displayedTrades.length && <tr><td colSpan={columnPreset === 'Basic' ? 14 : columnPreset === 'AutoTrender' ? 16 : 18} className="empty-cell">{loading ? 'Loading canonical trades…' : 'No trades match these filters. Create a paper trade or sync live positions.'}</td></tr>}
    </tbody></table></div><div className="panel-footer">Durable lifecycle events are saved immediately. Quote and unrealized P&amp;L updates are cache-only. Live broker reconciliation is read-only and remains a separate integration step.</div></section>
  </section>;
}
